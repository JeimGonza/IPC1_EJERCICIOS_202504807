Algoritmo Tarea_1
    Definir p, i, j Como Entero
    
    Escribir "Ingrese la cantidad de niveles:"
    Leer p
    Para i <- 1 Hasta p Hacer
        Si i < p Entonces
            Para j <- 1 Hasta (p - i) Hacer
                Escribir " " Sin Saltar
            FinPara
        FinSi
        Para j <- 1 Hasta (2*i - 1) Hacer
            Escribir "*" Sin Saltar
        FinPara
        Escribir ""
		
    FinPara
FinAlgoritmo
